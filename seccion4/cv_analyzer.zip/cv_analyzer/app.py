import streamlit as st
from ui.streamlit_ui import main

if __name__ == "__main__":
    main()