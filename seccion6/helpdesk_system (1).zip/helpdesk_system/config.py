CHROMADB_PATH = "C:\\Users\\santiago\\curso_langchain\\Tema 4\\helpdesk_system\\chroma_db"
DOCS_PATH = "C:\\Users\\santiago\\curso_langchain\\Tema 4\\helpdesk_system\\docs"
EMBEDDINGS_MODEL = "text-embedding-3-large"